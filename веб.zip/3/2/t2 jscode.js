let time = {
    hours: 0,
    minutes: 0,
    seconds: 0,

    showtime : function(){
        let displayhours = this.addzero(this.hours);
        let displayminutes = this.addzero(this.minutes);
        let displayseconds = this.addzero(this.seconds);
        alert(displayhours + ":" + displayminutes + ":" + displayseconds);
    },

    addzero : function(num){
        if (num < 10){
            return "0" + num 
        }
        else{
            return num
        }
    },

    addseconds : function(seconds) {
        let totalSeconds = this.hours * 3600 + this.minutes * 60 + this.seconds + seconds;
        this.hours = Math.floor(totalSeconds / 3600) % 24;
        this.minutes = Math.floor((totalSeconds % 3600) / 60);
        this.seconds = totalSeconds % 60;
    },

    addMinutes : function(minutes) {
        var date = new Date();
        date.setHours(this.hours);
        date.setMinutes(this.minutes + minutes);
        date.setSeconds(this.seconds);

        this.hours = date.getHours();
        this.minutes = date.getMinutes();
        this.seconds = date.getSeconds();
    },

    addHours : function(hours) {
        var date = new Date();
        date.setHours(this.hours + hours);
        date.setMinutes(this.minutes);
        date.setSeconds(this.seconds);

        this.hours = date.getHours();
        this.minutes = date.getMinutes();
        this.seconds = date.getSeconds();
    }
}

time.hours = parseInt(prompt("Hours:"));
time.minutes = parseInt(prompt("Minutes:"));
time.seconds = parseInt(prompt("Seconds:"));

// time.showtime();

// let m = parseInt(prompt("plus minutes:"));
// time.addminutes(m);

// adds = parseInt(prompt("Add seconds:"));
// time.addseconds(adds);
// time.showtime();

// adds = parseInt(prompt("Add minutes:"));
// time.addMinutes(adds);
// time.showtime();

adds = parseInt(prompt("Add hours:"));
time.addHours(adds);
time.showtime();