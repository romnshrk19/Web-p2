let list = [];

function addItem(name, quantity) {
    let findIndex = list.findIndex(item => item.name === name);
    if (findIndex !== -1) {
        list[findIndex].quantity += quantity;
    } else {
        let newItem = {
            name: name,
            quantity: quantity,
            bought: false
        };
        list.push(newItem);
    }
    alert(`${name} in number of ${quantity} is added`);
}


function display() {
    let output = "list:\n\n";
    let sortedlist = list.sort((a, b) => (a.bought === b.bought) ? 0 : a.bought ? 1 : -1);
    sortedlist.forEach((item, index) => {
        output += `${index + 1}. ${item.name} - ${item.quantity} - ${item.bought ? 'bought' : 'not bought'}\n`;
    });
    alert(output);
}

function bought(name){
    let item = list.find(item => item.name === name);
    if (item) {
        item.bought = true;
        alert(`${item.name} is marked as bought`);
    } else {
        alert(`no such product in list`);
    }
}

let f = true;
do {
    let name = prompt("name?");
    let q = parseInt(prompt("quantity?"));
    addItem(name, q);
    f = confirm("add another item?");
} while (f)
display();
f = false;
do {
    let name = prompt("name of bought item");
    bought(name);
    display();
    f = confirm("end shopping?");
} while (!f)
