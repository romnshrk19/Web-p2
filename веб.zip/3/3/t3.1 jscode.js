let check = [
    {name: "pear", quantity: 4, price: 23},
    {name: "bread", quantity: 2, price: 34},
    {name: "milk", quantity: 1, price: 50}
];

function total(){
    let total = 0;
    check.forEach(item => {total += item.price * item.quantity});
    return total
}

function exp(){
    let a = check.reduce((first, second) => {
        if (first.price > second.price){
            return first.name
        }
        else{
            return second.name
        }
    })
    return a; 
}

function average(){
    let quantity = 0
    check.forEach((item) => {
        quantity += 1
    })
    return total() /  quantity
}

function display() {
    let list = 'Your Check:\n';
    check.forEach(item => {
        list += `${item.name} - ${item.quantity} - ${item.price} money per item\n`;
    });
    list += "\nAverage: " + average() + " money";
    list += "\nMost expensive: " + exp() + "\n";
    list += "\nTotal: " + total() + "\n";
    alert(list);
}


display();