function stringcomp(str1, str2){
    if(str1.length > str2.length){
        return 1
    }
    if(str1.length < str2.length){
        return -1
    }
    else {
        return 0
    }

}

function firstcap(str1){
    let first = str1.charAt(0).toUpperCase();
    let rem = str1.slice(1);
    return first + rem;

}

function numofvowels(str1){
    let vows = "AEOIUYaeoiuy"
    count = 0
    for (let i = 0;i <= str1.length; i++){
        for(let j = 0; j <= vows.length; j++){
            if (str1.charAt(i) == vows.charAt(j)){
                count += 1
            }
        }
    }
    return(count)
}

function spamCheck(str1) {
    let spam = ["100%безкоштовно", "збільшення продажів", "тільки сьогодні", "не видаляйте", "xxx"];
    for (let i = 0; i < spam.length; i++) {
        let spamw = spam[i].toLowerCase();
        if (str1.toLowerCase().includes(spamw)) {
            return true;
        }
    }
    return false;
}

function shortenString(str1, num){
    if (str1.length > num){
        return str1.slice(0, num) + "..."
    }
    else {
        return str1
    }

}

function symbol(str1, a){
    let indexes = ""
    count = 0
    for (let i = 0; i <= str1.length; i++){
        if (str1.charAt(i) == a){
            count += 1
            indexes += i + ", "
        }
    }
    return "indexes: " + indexes + "count: " + count
}


// let s1 = prompt("sting 1:");
// let s2 = prompt("string 2:");
// alert(stringcomp(s1, s2))

// let s1 = prompt("string:")
// alert(firstcap(s1))

// let s1 = prompt("string:")
// alert(numofvowels(s1))

// let s1 = prompt("string:")
// alert(spamCheck(s1))

// let s1 = prompt("string:")
// let n = prompt("max length:")
// alert(shortenString(s1, n))

let s1 = prompt("string:")
let a = prompt("symbol:")
alert(symbol(s1, a))
