window.addEventListener('load', function() {
    let field = document.getElementById('field');
    let ball = document.getElementById('ball');
    field.addEventListener('click', function(event) {
        let fieldRect = field.getBoundingClientRect();
        let fieldWidth = field.offsetWidth;
        let fieldHeight = field.offsetHeight;
        let ballWidth = ball.offsetWidth;
        let ballHeight = ball.offsetHeight;
        let clickX = event.clientX - fieldRect.left;
        let clickY = event.clientY - fieldRect.top;
        let ballX = Math.min(Math.max(clickX - ballWidth / 2, 0), fieldWidth - ballWidth);
        let ballY = Math.min(Math.max(clickY - ballHeight / 2, 0), fieldHeight - ballHeight);
        ball.style.transform = `translate(${ballX}px, ${ballY}px)`;
    });
});

