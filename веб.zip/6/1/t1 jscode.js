function checkInput(event) {
    let input = event.target.value;
    let ch = "";
    for (let i = 0; i < input.length; i++) {
        let char = input[i];
        if (isNaN(char)) {
            ch += char;
        }
    }
    event.target.value = ch;
}
