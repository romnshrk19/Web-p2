document.addEventListener('keydown', function(event) {
    if (event.ctrlKey && event.key === 'y') {
        event.preventDefault();
        replaceWithTextarea();
    } else if (event.ctrlKey && event.key === 's') {
        event.preventDefault();
        replaceWithDiv();
    }
});

function replaceWithTextarea() {
    var textContent = document.getElementById('text-content').textContent;
    var textarea = document.createElement('textarea');
    textarea.value = textContent;
    textarea.id = 'text-input';

    var textContainer = document.getElementById('text-container');
    textContainer.innerHTML = '';
    textContainer.appendChild(textarea);

    textarea.focus();
}

function replaceWithDiv() {
    var textarea = document.getElementById('text-input');
    var textContent = textarea.value;
    var div = document.createElement('div');
    div.textContent = textContent;
    div.id = 'text-content';

    var textContainer = document.getElementById('text-container');
    textContainer.innerHTML = '';
    textContainer.appendChild(div);
}

