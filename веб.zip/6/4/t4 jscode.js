window.addEventListener('load', function() {
    let slider = document.querySelector('.slider');
    let currentSlide = 0;
    function changeSlide() {
        currentSlide = (currentSlide + 1) % slider.children.length;
        slider.style.transform = `translateX(-${currentSlide * 20}%)`;
    }
    slider.addEventListener('click', changeSlide);
});


