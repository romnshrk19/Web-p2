function appendNumber(number) {
    let result = document.getElementById('result');
    result.value += number;
}

function appendOperator(operator) {
    let result = document.getElementById('result');
    result.value += operator;
}

function clearResult() {
    let result = document.getElementById('result');
    result.value = "";
}

function calculateResult() {
    let result = document.getElementById('result');
    try {
        result.value = eval(result.value);
    } catch (error) {
        result.value = 'Error';
    }
}
