let $input_name = document.getElementById("input_name") // Змінна отримує посилання на елемент веб-сторінки за (ID) 
let $button_name = document.getElementById("button_name") // Змінна отримує посилання на елемент веб-сторінки за (ID) 
let $result = document.getElementById("result") // Змінна отримує посилання на елемент веб-сторінки за (ID) 

$button_name.addEventListener("click", getname) // Обробник подій призначає функцію getname при дії натискання

function getname() // Функція отримання імені
{
    let name = $input_name.value // Змінна name отримує значення, витягнуте з полля вводу input_name
    $result.innerText = "Ваше ім'я: " + name; // Встановлення значення змінної name як вмісту result
}