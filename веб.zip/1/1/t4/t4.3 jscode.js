let $input = document.getElementById("input");
let $button = document.getElementById("button");
let $output_Result = document.getElementById("output_Result");

$button.addEventListener("click", myfunc);

function myfunc(){
    let year = $input.value;
    if(parseInt(year)<0){
        $output_Result.innerText = "Помилка, введіть правильне значення!"
    }
    else{
        if(year%400 == 0 && year%100 != 0  || year%4 == 0 && year%100 != 0  ){
            $output_Result.innerText = year + " є високосним роком"
        }
        else{
            $output_Result.innerText = year + " не є високосним роком"
        }
    }
}    
