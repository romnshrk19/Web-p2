let $input = document.getElementById("input");
let $button = document.getElementById("button");
let $output_Result = document.getElementById("output_Result");

$button.addEventListener("click", myfunc);

function myfunc()
{
    let sum = $input.value
    switch (true)
    {
      case(sum >= 200 && sum < 300): $output_Result.innerText = "Знижка 3%, до сплати: " + (sum - (sum*3/100)); break;
      case(sum >= 300 && sum < 500): $output_Result.innerText = "Знижка 5%, до сплати: " + (sum - (sum*5/100)); break;
      case(sum >= 500): $output_Result.innerText = "Знижка 7%, до сплати: " + (sum - (sum*7/100)); break;
      case(sum < 200): $output_Result.innerText = "Знижки немає, до сплати: " + sum; break;
      default: $output_Result.innerText = "Помилка, введіть коректне значення!"; break;
    }
}    
