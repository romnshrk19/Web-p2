let $input = document.getElementById("input");
let $button = document.getElementById("button");
let $output_Result = document.getElementById("output_Result");

$button.addEventListener("click", myfunc);

function myfunc(){
    let age = $input.value;
    switch (parseInt(age)){
        case (0) : $output_Result.innerText  = "Символ, що відповідає "+age+" - )"; break;
        case (1) : $output_Result.innerText  = "Символ, що відповідає "+age+" - !"; break;
        case (2) : $output_Result.innerText  = "Символ, що відповідає "+age+" - @"; break;
        case (3) : $output_Result.innerText  = "Символ, що відповідає "+age+" - №"; break;
        case (4) : $output_Result.innerText  = "Символ, що відповідає "+age+" - ;"; break;
        case (5) : $output_Result.innerText  = "Символ, що відповідає "+age+" - %"; break;
        case (6) : $output_Result.innerText  = "Символ, що відповідає "+age+" - :"; break;
        case (7) : $output_Result.innerText  = "Символ, що відповідає "+age+" - ?"; break;
        case (8) : $output_Result.innerText  = "Символ, що відповідає "+age+" - *"; break;
        case (9) : $output_Result.innerText  = "Символ, що відповідає "+age+" - ("; break;
        default: $output_Result.innerText = "Введіть правильне число!"; break;
    }    
}