let $input = document.getElementById("input");
let $button = document.getElementById("button");
let $output_Result = document.getElementById("output_Result");

$button.addEventListener("click", myfunc);

function myfunc(){
    let age = $input.value;
    switch (true){
        case (age < 0): $output_Result.innerText = "Ще ненародилися"; break;
        case (age >= 0 && age < 2) : $output_Result.innerText = "Дитина"; break;
        case (age > 2 && age < 18) : $output_Result.innerText = "Підліток"; break;
        case (age > 18 && age < 60) : $output_Result.innerText = "Дорослий"; break;
        case (age > 60) : $output_Result.innerText = "Пенсіонер"; break;
    }
}