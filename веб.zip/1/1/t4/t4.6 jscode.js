let $round = document.getElementById("round");
let $square = document.getElementById("square");
let $button = document.getElementById("button");
let $output_Result = document.getElementById("output_Result");

$button.addEventListener("click", myfunc);

function myfunc()
{
let sqare_side = $square.value/4
let round_radius = $round.value/(Math.PI)
sqare_side > 0 && round_radius > 0?(sqare_side >= round_radius ? $output_Result.innerText = "Коло поміститься" : $output_Result.innerText = "Коло не поміститься") : $output_Result.innerText = "Помилка, введіть коректне значення!" 
}    
