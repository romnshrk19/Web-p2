let $button = document.getElementById("button");
let $output_Result = document.getElementById("output_Result");

$button.addEventListener("click", myfunc);

function myfunc()
{
  let input_1 = document.getElementById("input_1").selectedIndex;
  let input_2 = document.getElementById("input_2").selectedIndex;
  let input_3 = document.getElementById("input_3").selectedIndex;
  let sum = 0
    if (input_1 == 1){
      sum += 2
    }
    if (input_2 == 1){
      sum += 2
    }
    if (input_3 == 2){
      sum += 2
    }
  $output_Result.innerText = "Ваш результат: " + sum
}    
