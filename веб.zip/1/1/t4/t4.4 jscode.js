let $input = document.getElementById("input");
let $button = document.getElementById("button");
let $output_Result = document.getElementById("output_Result");

$button.addEventListener("click", myfunc);

function myfunc()
{
    let number = $input.value;
    let number1 = number.split('')
    number1.reverse()
    number1 = number1.join('')
    number >= 10000 && number <= 99999 ?(parseInt(number1) === parseInt(number) ? $output_Result.innerText = "Паліндром" : $output_Result.innerText = "Не паліндром"): $output_Result.innerText = "Помилка, введіть правильне значення!"
}    
