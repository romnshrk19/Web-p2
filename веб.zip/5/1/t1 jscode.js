function accordion(header) {
    let accordionItems = document.querySelectorAll('.accordion-item');
    accordionItems.forEach(function(item) {
        item.classList.remove('active');
        item.querySelector('.accordion-content').style.display = 'none';
    });
    let accordionItem = header.parentNode;
    let accordionContent = accordionItem.querySelector('.accordion-content');
    accordionItem.classList.add('active');
    accordionContent.style.display = 'block';
}
