function addBlock() {
    let container = document.getElementById("container");
    let block = document.createElement("div");
    block.classList.add("block");
    block.style.backgroundColor = getRandomColor();
    container.appendChild(block);
    block.addEventListener("click", function() {
        container.removeChild(block);
    });
}

function getRandomColor() {
    let letters = "0123456789abcdef";
    let color = "#";
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];


    }
    return color;
}

