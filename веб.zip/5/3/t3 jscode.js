function applyFormatting() {
    let editor = document.getElementById("editor");
    let color = document.getElementById("color").value;
    let style = document.getElementById("style").value;
    let size = document.getElementById("size").value;
    let font = document.getElementById("font").value;
    editor.style.color = color;
    editor.style.fontStyle = style;
    editor.style.fontSize = size + "px";
    editor.style.fontFamily = font;
}
