let score = 0;
let currentTask = "";

generateTask();
function generateTask() {
    let num1 = Math.floor(Math.random() * 9) + 1;
    let num2 = Math.floor(Math.random() * 9) + 1;
    currentTask = num1 + " * " + num2;
    document.getElementById("task").textContent = "Обрахуйте: " + currentTask;
}

function nextTask() {
    generateTask();
    document.getElementById("answer").value = "";
    document.getElementById("result").textContent = "";
}

function checkAnswer() {
    let userAnswer = parseInt(document.getElementById("answer").value);
    let correctAnswer = eval(currentTask);
    let resultText = "";
    if (userAnswer === correctAnswer) {
        resultText = "Правильно!";
        score += 10;
    } else {



        resultText = "Неправильно, " + correctAnswer;
    }
    document.getElementById("result").textContent = resultText;
    document.getElementById("score").textContent = "Рахунок: " + score +"%";
    generateTask();
}
