function addComment(event) {
    let nameInput = event.target.previousElementSibling.previousElementSibling;
    let commentInput = event.target.previousElementSibling;
    let name = nameInput.value;
    let commentText = commentInput.value;
    let commentElement = document.createElement("div");
    commentElement.classList.add("comment");
    commentElement.innerHTML = "<strong>" + name + "</strong><br>" + commentText;
    let articleElement = event.target.parentElement;
    articleElement.appendChild(commentElement);
    nameInput.value = "";
    commentInput.value = ""
}

