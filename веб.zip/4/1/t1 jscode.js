
function getDayOfWeek(date) {
    const daysOfWeek = [
        'Понеділок',
        'Вівторок',
        'Середа',
        'Четвер',
        'П’ятниця',
        'Субота',
        'Неділя'
    ];
    const dayNumber = date.getDay();
    const dayName = daysOfWeek[dayNumber - 1];
    return {
        dayNumber,
        dayName
    };
}

function displayDate() {
    let currentDate = new Date();
    let daysOfWeek = ['Неділя', 'Понеділок', 'Вівторок', 'Середа', 'Четвер', 'Пʼятниця', 'Субота'];
    let dayOfWeek = daysOfWeek[currentDate.getDay()];
    let months = ['січня', 'лютого', 'березня', 'квітня', 'травня', 'червня', 'липня', 'серпня', 'вересня', 'жовтня', 'листопада', 'грудня'];
    let month = months[currentDate.getMonth()];
    let day = currentDate.getDate();
    let year = currentDate.getFullYear();
    let hours = currentDate.getHours();
    let minutes = currentDate.getMinutes();
    let outputDate = `Дата: ${day} ${month} ${year} року<br>День тижня: ${dayOfWeek}<br>Час: ${hours}:${minutes}`;
    document.getElementById("output1").innerHTML = outputDate;
}

function dateDifference() {
    let date1Input = document.getElementById('input3');
    let date2Input = document.getElementById('input4');
    let date1 = new Date(date1Input.value);
    let date2 = new Date(date2Input.value);
    let difference = datediff(date1, date2);
    let output = document.getElementById('output7');
    output.textContent = 'Різниця: ' + difference.days;
}


function displayDay() {
    const currentDate = new Date();
    const dayInfo = getDayOfWeek(currentDate);
    let outputDate = `Номер дня: ${dayInfo.dayNumber} <br> Назва дня: ${dayInfo.dayName}`;
    document.getElementById("output2").innerHTML = outputDate;
}

function getDateAgo() {
    let daysAgoInput = document.getElementById('input1');
    let daysAgoValue = parseInt(daysAgoInput.value);
    let currentDate = new Date();
    currentDate.setDate(currentDate.getDate() - daysAgoValue);
    let daysOutput = document.getElementById('output3');
    daysOutput.textContent = currentDate.toDateString();
}

function getDaySeconds(){
    let now = new Date();
    let startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    let secondsPassed = Math.floor((now - startOfDay) / 1000);
    let secondsRemaining = 86400 - secondsPassed;
    let Output = `Пройшло секунд: ${secondsPassed} <br> До наступного дня: ${secondsRemaining}`;
    document.getElementById("output5").innerHTML = Output;

}

function getLastOfTheMonth(){
    let yearInput = document.getElementById('inputy');
    let monthInput = document.getElementById('inputn');
    let Output = document.getElementById('output4');
    let year = parseInt(yearInput.value);
    let month = parseInt(monthInput.value);
    let date = new Date(year, month, 0);
    let lastDay = date.getDate();
    Output.textContent = 'Останній день: ' + lastDay;
    
} 

function getdateinstring(){
    let dateInput = document.getElementById('input2');
    let selectedDate = new Date(dateInput.value);
    let formattedDate = selectedDate.toLocaleDateString('uk-UA');
    let formattedDateOutput = document.getElementById('output6');
    formattedDateOutput.textContent = formattedDate;

}

function datediff(date1, date2){
    let difference = Math.abs(date1 - date2);
    let millisecondsPerDay = 1000 * 60 * 60 * 24;
    let days = Math.floor(difference / millisecondsPerDay);
    return {
        days: days
    }
}
//

function getFormatDate() {
    let datetime = document.getElementById("inputdt").value;
    let fd = formatDate(new Date(datetime));
    let output = document.getElementById('output8');
    output.textContent = fd;
}

function formatDate(date) {
    let now = new Date(2024, 8, 29);
    let diff = Math.floor((now - date) / 1000);
    if (diff < 1) {
        return "тільки що";
    } else if (diff < 60) {
        return diff + " сек. назад";
    } else if (diff < 3600) {
        let minutes = Math.floor(diff / 60);
        return minutes + " хв. назад";
    } else {
        let day = date.getDate();
        let month = date.getMonth() + 1;
        let year = date.getFullYear();
        let hours = date.getHours();
        let minutes = date.getMinutes();
        day = day < 10 ? "0" + day : day;
        month = month < 10 ? "0" + month : month;
        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        return day + "." + month + "." + year + " " + hours + ":" + minutes;
    }
}
//

function submitDate() {
    let inputDate = document.getElementById("inputd").value;
    let date = parseDate(inputDate);
    if (date) {
        let formattedDate = formatDate1(date);
        document.getElementById("output9").textContent = formattedDate;
    } else {
        document.getElementById("output9").textContent = "Невірний формат дати";
    }
}

function parseDate(dateString) {
    let parts = dateString.split(/[-./]/);
    let day, month, year;
    if (parts.length === 3) {
        if (parts[0].length === 2 && parts[1].length === 2 && parts[2].length === 4) {
            day = parseInt(parts[0], 10);
            month = parseInt(parts[1], 10);
            year = parseInt(parts[2], 10);



        } else if (parts[0].length === 4 && parts[1].length === 2 && parts[2].length === 2) {
            day = parseInt(parts[2], 10);
            month = parseInt(parts[1], 10);
            year = parseInt(parts[0], 10);
        } else {
            return null;
        }
        if (month < 1 || month > 12 || day < 1 || day > 31) {
            return null;
        }
        return new Date(year, month - 1, day);
    } else {
        return null;
    }
}



function formatDate1(date) {
    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    return day + "." + month + "." + year;
}
//
function getFormattedLanDate() {
    let datetimeInput = document.getElementById('inputdt1');
    let languageInput = document.getElementById('inputl');
    let date = new Date(datetimeInput.value);
    let language = languageInput.value;
    let formattedDate = formatLanDate(date, language);
    let output = document.getElementById('output10');
    output.textContent = formattedDate;
}

function formatLanDate(date, language) {
    let options = {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric',
    };
    let formatter = new Intl.DateTimeFormat(language, options);
    let formattedDate = formatter.format(date);
    formattedDate += ' нашої ери';
    return formattedDate;
}

