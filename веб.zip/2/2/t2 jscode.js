function toCamelCase(snakeCase) {
    return snakeCase.replace(/_([a-z])/g, function(match, char) {
        return char.toUpperCase();
    });
}

function toSnakeCase(camelCase) {
    return camelCase.replace(/[A-Z]/g, function(match) {
        return '_' + match.toLowerCase();
    });
}

function replaceDates(text) {
    return text.replace(/\b(\d{4})\/(\d{2})\/(\d{2})\b/g, function(match, year, month, day) {
        return day + '.' + month + '.' + year;
    });
}

let str = prompt('text in snake case', '');
str = toCamelCase(str);
alert(`text in camel case: ${str}`);

str = prompt('text in camel case', '');
str = toSnakeCase(str);
alert(`text in snake case: ${str}`);

str = prompt('input text with dates', '');
str = replaceDates(str);
alert(`text with dates in different format: ${str}`);

