// let n = parseInt(prompt('input number'));
// let res = "";
// for (let i = 1; i <= 100; i++) {
//     if (i % n === 0) {
//         res += i + " ";
//     }
// }
// alert(res);


// let min = parseInt(prompt('min:'));
// let max = parseInt(prompt('max:'));
// res = "";
// for (let i = min; i <= max; i++) {
//     if ((i - min) % 4 === 0) {
//         res += i + " ";
//     }
// }
// alert(res);

// let a = parseInt(prompt('a:'));
// let b = parseInt(prompt('b:'));
// if (a > b) {
//     let temp = a;
//     a = b;
//     b = temp;
// }
// let sum = 0;
// let count = 0;
// res = "";
// for (let i = a; i<=b; i++) {
//     res += i + " ";
//     sum += i;
//     count ++;
// }
// alert(res + `\n s: ${sum} \n c: ${count}`);

// n = parseInt(prompt('number:'));
// res = "";
// for (let i = n; i >=0; i--) {
//     res += i + " ";
// }
// alert(res);

// let n = parseInt(prompt('number:'));
// let m = parseInt(prompt('power:'));
// let res = 1;
// for (let i = 0; i <m; i++) {
//     res *= n
// }
// alert(res);

// let n = parseInt(prompt('number:'));
// let m = parseInt(prompt('power:'));
// let res = 1;
// for (let i = 0; i <m; i++) {
//     res *= n
// }
// alert(res);

// let c;
// n = null;
// max = -Infinity;
// res = ""
// do {
//     c = n;
//     n = parseInt(prompt("n:"));
//     if (n > max)
//         max = n;
//     res += n + " "
// } while (n !== c)
// alert(`string:${res}, max:${max}`);

// let days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
// let ind = 0;
// let cont = true;
// while(cont) {
//     cont = confirm(`Day: ${days[ind]}, continue?`);
//     ind = (ind + 1) % days.length;
// }

let table = ""
for(let i = 2; i <=9 ; i++){
    for(let j = 1; j <=10; j++){
        let mul = i * j
        table += i + " * " + j + " = " + mul + "\n"
    }
    table += "\n"
}
alert(table)
