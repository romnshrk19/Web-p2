let a = 2;
let b = 3;
let c, d;
c = ++a;
d = b++;
c = (2+ ++a);
d = (2+ b++);

alert(a);
alert(b);
alert(c);
alert(d);
